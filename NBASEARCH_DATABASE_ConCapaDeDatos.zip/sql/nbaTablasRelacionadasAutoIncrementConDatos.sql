CREATE DATABASE  IF NOT EXISTS `nba` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_spanish2_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `nba`;
-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: nba
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `conferencia`
--

DROP TABLE IF EXISTS `conferencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conferencia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conferencia`
--

LOCK TABLES `conferencia` WRITE;
/*!40000 ALTER TABLE `conferencia` DISABLE KEYS */;
INSERT INTO `conferencia` VALUES (1,'este'),(2,'oeste');
/*!40000 ALTER TABLE `conferencia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `division`
--

DROP TABLE IF EXISTS `division`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `division` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `division`
--

LOCK TABLES `division` WRITE;
/*!40000 ALTER TABLE `division` DISABLE KEYS */;
INSERT INTO `division` VALUES (1,'sudeste'),(2,'atlántico'),(3,'central'),(4,'sudoeste'),(5,'noroeste'),(6,'pacífico');
/*!40000 ALTER TABLE `division` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipo`
--

DROP TABLE IF EXISTS `equipo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idConferencia` int(11) NOT NULL,
  `idDivision` int(11) NOT NULL,
  `nombre` varchar(45) CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  `campeon` tinyint(4) NOT NULL DEFAULT '0',
  `escudo` blob,
  PRIMARY KEY (`id`),
  KEY `fk_equipo_conferencia_idx` (`idConferencia`),
  KEY `fk_equipo_division1_idx` (`idDivision`),
  CONSTRAINT `fk_equipo_conferencia` FOREIGN KEY (`idConferencia`) REFERENCES `conferencia` (`id`),
  CONSTRAINT `fk_equipo_division1` FOREIGN KEY (`idDivision`) REFERENCES `division` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipo`
--

LOCK TABLES `equipo` WRITE;
/*!40000 ALTER TABLE `equipo` DISABLE KEYS */;
INSERT INTO `equipo` VALUES (1,1,1,'Atlanta Hawks',0,NULL),(2,1,2,'Boston Celtics',0,NULL),(3,1,2,'Brooklyn Nets',0,NULL),(4,1,3,'Chicago Bulls',0,NULL),(5,1,1,'Charlotte Hornets',0,NULL),(6,1,3,'Cleveland Cavaliers',0,NULL),(7,2,4,'Dallas Mavericks',0,NULL),(8,2,5,'Denver Nuggets',0,NULL),(9,1,3,'Detroit Pistons',0,NULL),(10,2,6,'Golden State Warriors',0,NULL),(11,2,4,'Houston Rockets',0,NULL),(12,1,3,'Indiana Pacers',0,NULL),(13,2,6,'Los Angeles Clippers',0,NULL),(14,2,6,'Los Angeles Lakers',0,NULL),(15,2,4,'Memphis Grizzlies',0,NULL),(16,1,1,'Miami Heat',0,NULL),(17,1,3,'Milwaukee Bucks',0,NULL),(18,2,5,'Minnesota Timberwolves',0,NULL),(19,2,4,'New Orleans Pelicans',0,NULL),(20,1,2,'New York Knicks',0,NULL),(21,2,5,'Oklahoma City Thunder',0,NULL),(22,1,1,'Orlando Magic',0,NULL),(23,1,2,'Philadelphia 76ers',0,NULL),(24,2,6,'Phoenix Suns',0,NULL),(25,2,5,'Portland Trail Blazers',0,NULL),(26,2,6,'Sacramento Kings',0,NULL),(27,2,4,'San Antonio Spurs',0,NULL),(28,1,2,'Toronto Raptors',0,NULL),(29,2,5,'Utah Jazz',0,NULL),(30,1,1,'Washington Wizards',0,NULL);
/*!40000 ALTER TABLE `equipo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jugadoractual`
--

DROP TABLE IF EXISTS `jugadoractual`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jugadoractual` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idEquipo` int(11) NOT NULL,
  `nombre` varchar(45) CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  `apellidos` varchar(90) CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  `idPosicion` int(11) NOT NULL,
  `fechaAltaClub` date DEFAULT NULL,
  `campeon` tinyint(4) NOT NULL DEFAULT '0',
  `altura` double NOT NULL DEFAULT '0',
  `peso` double NOT NULL DEFAULT '0',
  `temporadasClub` int(11) NOT NULL DEFAULT '0',
  `dorsal` int(11) NOT NULL DEFAULT '0',
  `foto` blob,
  PRIMARY KEY (`id`),
  KEY `fk_jugadoractual_posicion1_idx` (`idPosicion`),
  KEY `fk_jugadoractual_equipo1_idx` (`idEquipo`),
  CONSTRAINT `fk_jugadoractual_equipo1` FOREIGN KEY (`idEquipo`) REFERENCES `equipo` (`id`),
  CONSTRAINT `fk_jugadoractual_posicion1` FOREIGN KEY (`idPosicion`) REFERENCES `posicion` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jugadoractual`
--

LOCK TABLES `jugadoractual` WRITE;
/*!40000 ALTER TABLE `jugadoractual` DISABLE KEYS */;
INSERT INTO `jugadoractual` VALUES (1,2,'Carsen','Edwards',1,NULL,0,1.8,90.7,0,4,NULL),(2,2,'Jaylen','Brown',2,NULL,0,1.98,101.2,0,7,NULL),(3,2,'Gordon','Hayward',3,NULL,0,2.01,102.1,0,20,NULL),(4,2,'Tacko','Fall',4,NULL,0,2.26,141.1,0,99,NULL),(5,2,'Vincent','Poirier',5,NULL,0,2.13,106.6,0,77,NULL),(6,4,'Ryan','Arcidiacono',1,NULL,0,1.9,88.5,0,51,NULL),(7,4,'Zach','LaVine',2,NULL,0,1.98,90.7,0,8,NULL),(8,4,'Chandler','Hutchison',3,NULL,0,2.01,95.3,0,15,NULL),(9,4,'Luke','Kornet',5,NULL,0,2.18,113.4,0,2,NULL),(10,4,'Daniel','Gafford',5,NULL,0,2.08,106.1,0,12,NULL),(11,5,'Devonte\'','Graham',1,NULL,0,1.85,88.5,0,4,NULL),(12,5,'Dwayne','Bacon',2,NULL,0,1.98,100.2,0,7,NULL),(13,5,'Miles','Bridges',3,NULL,0,1.98,102.1,0,0,NULL),(14,5,'Bismack','Biyombo',4,NULL,0,2.03,115.7,0,8,NULL),(15,5,'Willy','Hernan Gomez',5,NULL,0,2.11,113.7,0,9,NULL),(16,6,'Kevin','Porter Jr.',1,NULL,0,1.93,92.1,0,4,NULL),(17,6,'Tyler','Cook',2,NULL,0,2.03,115.7,0,21,NULL),(18,6,'Matthew','Dellavedova',3,NULL,0,1.9,90.7,0,18,NULL),(19,6,'Kevin','Love',4,NULL,0,2.03,113.9,0,0,NULL),(20,6,'Dean','Wade',5,NULL,0,2.06,103.4,0,32,NULL),(21,7,'J.J.','Barea',1,NULL,0,1.78,81.6,0,5,NULL),(22,7,'Seth','Curry',2,NULL,0,1.88,83.9,0,30,NULL),(23,7,'Tim','Hardaway Jr.',3,NULL,0,1.96,93,0,11,NULL),(24,7,'Courtney','Lee',4,NULL,0,1.96,97.5,0,1,NULL),(25,7,'Delon','Wright',5,NULL,0,1.96,83.9,0,55,NULL),(26,9,'Bruce','Brown',1,NULL,0,1.93,91.6,0,6,NULL),(27,9,'Tony','Snell',2,NULL,0,1.98,96.6,0,17,NULL),(28,9,'Blake','Griffin',3,NULL,0,2.06,113.4,0,23,NULL),(29,9,'Thon','Maker',4,NULL,0,2.13,100.2,0,7,NULL),(30,9,'Christian','Wood',5,NULL,0,2.08,97.1,0,35,NULL),(31,10,'Stephen','Curry',1,NULL,0,1.9,83.9,0,30,NULL),(32,10,'Jacob','Evans',2,NULL,0,1.93,95.3,0,10,NULL),(33,10,'Klay','Thompson',3,NULL,0,1.98,97.5,0,11,NULL),(34,10,'Kevon','Looney',4,NULL,0,2.06,100.7,0,5,NULL),(35,10,'Willie','Cauley Stein',5,NULL,0,2.13,108.9,0,2,NULL),(36,14,'Alex','Caruso',1,NULL,0,1.96,84.4,0,4,NULL),(37,14,'Danny','Green',2,NULL,0,1.98,97.5,0,14,NULL),(38,14,'LeBron','James',3,NULL,0,2.06,113.4,0,23,NULL),(39,14,'DeMarcus','Cousins',4,NULL,0,2.08,122.5,0,15,NULL),(40,14,'Anthony','Davies',5,NULL,0,2.08,114.8,0,3,NULL),(41,16,'Goran','Dragić',1,NULL,0,1.9,86.2,0,7,NULL),(42,16,'Ok','Okpala',2,NULL,0,2.03,97.5,0,4,NULL),(43,16,'James','Johnson',3,NULL,0,2.01,108.9,0,16,NULL),(44,16,'Duncan','Robinson',4,NULL,0,2.01,97.5,0,55,NULL),(45,16,'Chris','Silva',5,NULL,0,2.03,106.1,0,30,NULL),(46,18,'Jeff','Teague',1,NULL,0,1.9,88.5,0,0,NULL),(47,18,'Jarrett','Culver',2,NULL,0,1.88,88.5,0,23,NULL),(48,18,'Jordan','Bell',3,NULL,0,2.03,98,0,7,NULL),(49,18,'Noah','Vonleh',4,NULL,0,2.08,116.6,0,1,NULL),(50,18,'Naz','Reid',5,NULL,0,2.06,119.7,0,11,NULL),(51,21,'Chris','Paul',1,NULL,0,1.85,79.4,0,3,NULL),(52,21,'Deonte','Burton',2,NULL,0,1.93,108.9,0,30,NULL),(53,21,'Steven','Adams',3,NULL,0,2.11,120.2,0,12,NULL),(54,21,'Nerlens','Noel',4,NULL,0,2.08,99.8,0,9,NULL),(55,21,'André','Roberson',5,NULL,0,2.01,95.3,0,21,NULL),(56,24,'Jevon','Carter',1,NULL,0,1.85,90.7,0,4,NULL),(57,24,'Ricky','Rubio',2,NULL,0,1.9,86.2,0,11,NULL),(58,24,'Cameron','Johnson',3,NULL,0,2.03,95.3,0,23,NULL),(59,24,'Aron','Baynes',4,NULL,0,2.08,117.9,0,46,NULL),(60,24,'Deandre','Ayton',5,NULL,0,2.11,113.4,0,22,NULL),(61,27,'Patty','Mills',1,NULL,0,1.85,81.6,0,8,NULL),(62,27,'Derrick','White',2,NULL,0,1.93,86.2,0,4,NULL),(63,27,'Trey','Lyles',3,NULL,0,2.06,106.1,0,41,NULL),(64,27,'Rudy','Gay',4,NULL,0,2.03,113.4,0,22,NULL),(65,27,'LeMarcus','Aldridge',5,NULL,0,2.11,113.4,0,12,NULL),(66,28,'Kyle','Lowry',1,NULL,0,1.83,88.9,0,7,NULL),(67,28,'Matt','Thomas',2,NULL,0,1.93,86.2,0,21,NULL),(68,28,'Chris','Boucher',3,NULL,0,2.06,90.7,0,25,NULL),(69,28,'Marc','Gasol',4,NULL,0,2.11,115.7,0,33,NULL),(70,28,'Serge','Ibaka',5,NULL,0,2.13,106.6,0,9,NULL);
/*!40000 ALTER TABLE `jugadoractual` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(45) CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  `password` varchar(45) CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  `dni` varchar(45) CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  `nombre` varchar(45) CHARACTER SET cp1256 COLLATE cp1256_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dni_UNIQUE` (`dni`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posicion`
--

DROP TABLE IF EXISTS `posicion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posicion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `posicion` varchar(45) CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posicion`
--

LOCK TABLES `posicion` WRITE;
/*!40000 ALTER TABLE `posicion` DISABLE KEYS */;
INSERT INTO `posicion` VALUES (1,'base'),(2,'escolta'),(3,'alero'),(4,'pivot'),(5,'ala-pivot');
/*!40000 ALTER TABLE `posicion` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-03 21:12:20
